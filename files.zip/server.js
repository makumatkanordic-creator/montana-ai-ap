const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors({ origin: "http://localhost:3000" }));
app.use(express.json());

// ضع الـ API Key هنا فقط — لا أحد يشوفه
const ANTHROPIC_KEY = "sk-ant-XXXXXXXXXXXXXXXX"; // ← ضع كيك هنا

app.post("/api/chat", async (req, res) => {
  try {
    const { prompt, system } = req.body;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: system || "",
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await response.json();
    res.json({ text: data.content?.[0]?.text || "خطأ في الرد" });
  } catch (err) {
    res.status(500).json({ text: "خطأ في السيرفر" });
  }
});

app.listen(3001, () => {
  console.log("✅ Montana AI Server شغال على http://localhost:3001");
});
